# Project ATM

---

### A C++ Application providing Banking Services.


![Project ATM](http://rohithvutnoor.com/images/project/ATM.png)





The basic difference between 32-bit and 64-bit projects is the inner configuration for Dev-C++ Software.

As the project includes some extra library file for providing audio system thus it has been split into two sets.

Only the include configuration changes and the entire source code remains same in both the systems.
